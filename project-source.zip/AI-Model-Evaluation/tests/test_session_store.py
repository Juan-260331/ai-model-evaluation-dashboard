from database.session_store import SessionExperimentStore


def test_history_cannot_be_read_from_another_session():
    first = SessionExperimentStore({})
    second = SessionExperimentStore({})
    summary = {"Demo Model A": {"accuracy": 1.0}}
    saved = first.save_experiment("private.csv", summary, [{"question": "Private"}])
    assert second.list_experiments() == []
    assert second.get_experiment(saved["experiment_id"]) is None
    assert first.get_experiment(saved["experiment_id"]) == saved
    assert "results" not in first.list_experiments()[0]


def test_history_survives_reruns_and_returns_newest_first():
    state = {}
    first = SessionExperimentStore(state).save_experiment("first.csv", {}, [])
    second = SessionExperimentStore(state).save_experiment("second.csv", {}, [])
    assert [item["experiment_id"] for item in SessionExperimentStore(state).list_experiments()] == [
        second["experiment_id"], first["experiment_id"]
    ]
    assert SessionExperimentStore({}).list_experiments() == []
