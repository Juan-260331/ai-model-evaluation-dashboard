import json

import pandas as pd
import pytest

from database.store import get_experiment, list_experiments, save_experiment
from evaluation.dataset import load_csv, validate_dataset
from evaluation.exporters import results_to_csv, summary_to_json
from evaluation.runner import compare_models, exact_match, normalize_answer
from models.demo_models import available_demo_models


def test_csv_format_validation():
    with pytest.raises(ValueError, match="CSV"):
        load_csv(b"question,expected_answer,category\nq,a,c\n", "dataset.txt")
    with pytest.raises(ValueError, match="Unable to read CSV"):
        load_csv(b"\xff\xfe", "dataset.csv")


def test_required_columns_are_checked():
    with pytest.raises(ValueError, match="expected_answer"):
        validate_dataset(pd.DataFrame({"question": ["q"], "category": ["c"]}))


def test_csv_preserves_literal_answers_and_leading_zeroes():
    dataset, report = load_csv(
        b"question,expected_answer,category\nEmpty Python value?,None,Programming\nCode?,001,Test\nLiteral?,NA,Test\nIncomplete?,,Test\n",
        "text-answers.csv",
    )
    assert dataset["expected_answer"].tolist() == ["None", "001", "NA"]
    assert report["dropped_empty"] == 1


def test_dataset_cleans_empty_rows_and_duplicates():
    data = pd.DataFrame([
        {"question": " Q ", "expected_answer": " A ", "category": " C "},
        {"question": "Q", "expected_answer": "A", "category": "C"},
        {"question": None, "expected_answer": "answer", "category": "C"},
    ])
    cleaned, report = validate_dataset(data)
    assert cleaned.to_dict(orient="records") == [{"question": "Q", "expected_answer": "A", "category": "C"}]
    assert report == {"dropped_empty": 1, "duplicates_removed": 1}


def test_answers_are_normalized_before_exact_match():
    assert normalize_answer("  HeLLo  ") == "hello"
    assert exact_match("  PARIS ", "paris")
    assert not exact_match("Paris!", "Paris")


def test_model_comparison_reports_accuracy_and_latency():
    dataset = pd.DataFrame([
        {"question": f"Question {i}", "expected_answer": f"Answer {i}", "category": "Test"}
        for i in range(10)
    ])
    results, summary = compare_models(dataset, available_demo_models())
    assert set(summary) == {"Demo Model A", "Demo Model B"}
    assert summary["Demo Model A"]["accuracy"] == 0.9
    assert summary["Demo Model B"]["accuracy"] == 0.7
    assert summary["Demo Model A"]["average_response_time_ms"] < summary["Demo Model B"]["average_response_time_ms"]
    assert len(results) == 20
    assert set(results["status"]) == {"Pass", "Fail"}


def test_reports_export_results_and_summary():
    rows = pd.DataFrame([{"question": "q", "passed": True}])
    csv_text = results_to_csv(rows)
    assert "question,passed" in csv_text
    payload = json.loads(summary_to_json({"Demo Model A": {"accuracy": 1.0}}, "sample.csv", "run-1"))
    assert payload["experiment_id"] == "run-1"
    assert payload["models"]["Demo Model A"]["accuracy"] == 1.0


def test_experiment_can_be_saved_and_read(tmp_path):
    database_path = tmp_path / "history.sqlite"
    summary = {"Demo Model A": {"accuracy": 0.75, "average_response_time_ms": 45.0}}
    results = [{"question": "q", "passed": True}]
    saved = save_experiment("sample.csv", summary, results, database_path)
    loaded = get_experiment(saved["experiment_id"], database_path)
    assert loaded is not None
    assert loaded["dataset_name"] == "sample.csv"
    assert loaded["metrics"] == summary
    assert loaded["results"] == results
    assert len(list_experiments(database_path)) == 1


def test_demo_model_results_are_reproducible():
    dataset = pd.DataFrame([
        {"question": f"Question {i}", "expected_answer": f"Answer {i}", "category": "Test"}
        for i in range(20)
    ])
    first_results, first_summary = compare_models(dataset, available_demo_models())
    second_results, second_summary = compare_models(dataset, available_demo_models())
    pd.testing.assert_frame_equal(first_results, second_results)
    assert first_summary == second_summary


def test_sample_dataset_has_sixty_rows_and_required_categories():
    from pathlib import Path

    sample_path = Path(__file__).resolve().parents[1] / "data" / "sample_dataset.csv"
    dataset, _ = load_csv(sample_path, sample_path.name)
    assert len(dataset) == 60
    assert set(dataset["category"]) == {"Mathematics", "General Knowledge", "Programming"}
    results, summary = compare_models(dataset, available_demo_models())
    assert len(results) == len(dataset) * 2
    assert summary["Demo Model A"]["accuracy"] != summary["Demo Model B"]["accuracy"]
    assert summary["Demo Model A"]["accuracy"] == 0.9
    assert summary["Demo Model B"]["accuracy"] == 0.7
    assert set(results["status"]) == {"Pass", "Fail"}
