import csv
import io
import json
from pathlib import Path

import pandas as pd
from streamlit.testing.v1 import AppTest

from database.store import get_experiment, list_experiments
from evaluation.exporters import results_to_csv, summary_to_json


def test_streamlit_pages_upload_evaluation_exports_and_history(monkeypatch, tmp_path):
    database_path = tmp_path / "app-history.sqlite"
    monkeypatch.setenv("DB_PATH", str(database_path))
    monkeypatch.setenv("HISTORY_STORAGE", "sqlite")

    project_root = Path(__file__).resolve().parents[1]
    app = AppTest.from_file(str(project_root / "app.py"), default_timeout=15).run()
    assert not app.exception

    pages = (
        "Dashboard",
        "Datasets",
        "Model Comparison",
        "Evaluation Results",
        "Experiment History",
    )
    assert tuple(app.radio[0].options) == pages
    for page in pages:
        app.radio[0].set_value(page).run()
        assert not app.exception
        assert any(page in title.value for title in app.title)

    app.radio[0].set_value("Datasets").run()
    app.file_uploader[0].set_value(("invalid.csv", b"wrong_header\nrow\n", "text/csv")).run()
    assert any("Missing required columns" in error.value for error in app.error)

    csv_buffer = io.StringIO()
    writer = csv.writer(csv_buffer)
    writer.writerow(("question", "expected_answer", "category"))
    for index in range(10):
        writer.writerow((f"Question {index}", f"Answer {index}", f"Category {index % 2}"))
    writer.writerow(("Question 0", "Answer 0", "Category 0"))
    writer.writerow(("", "", ""))

    app.file_uploader[0].set_value(
        ("portfolio.csv", csv_buffer.getvalue().encode(), "text/csv")
    ).run()
    assert not app.exception
    assert any("Validated 10 usable rows" in message.value for message in app.success)
    assert any(
        "1 incomplete row(s) and 1 duplicate row(s)" in message.value
        for message in app.info
    )
    next(button for button in app.button if button.label == "Use uploaded dataset").click().run()
    assert len(app.session_state["active_dataset"]) == 10

    app.radio[0].set_value("Model Comparison").run()
    assert any(
        "portfolio.csv" in field.value and "10 questions" in field.value
        for field in app.text_input
    )
    next(button for button in app.button if button.label == "Run evaluation").click().run()
    assert not app.exception
    assert any(title.value == "Evaluation Results" for title in app.title)
    assert len(app.dataframe[-1].value) == 20

    experiments = list_experiments()
    assert len(experiments) == 1
    experiment = get_experiment(experiments[0]["experiment_id"])
    assert experiment is not None
    assert len(experiment["results"]) == 20
    assert experiment["metrics"]["Demo Model A"]["accuracy"] == 0.9
    assert experiment["metrics"]["Demo Model B"]["accuracy"] == 0.7

    downloads = {button.label: button.proto.url for button in app.download_button}
    assert set(downloads) == {
        "Download per-question results (CSV)",
        "Download experiment summary (JSON)",
    }
    assert downloads["Download per-question results (CSV)"].endswith(".csv")
    assert downloads["Download experiment summary (JSON)"].endswith(".json")
    csv_report = results_to_csv(pd.DataFrame(experiment["results"]))
    csv_results = list(csv.DictReader(io.StringIO(csv_report)))
    assert len(csv_results) == 20
    assert {row["model_name"] for row in csv_results} == {"Demo Model A", "Demo Model B"}
    assert {row["status"] for row in csv_results} == {"Pass", "Fail"}

    json_report = json.loads(
        summary_to_json(experiment["metrics"], experiment["dataset_name"], experiment["experiment_id"])
    )
    assert json_report["experiment_id"] == experiment["experiment_id"]
    assert json_report["dataset_name"] == "portfolio.csv"
    assert json_report["models"] == experiment["metrics"]

    app.radio[0].set_value("Experiment History").run()
    assert not app.exception
    assert len(app.dataframe[-1].value) == 2
    next(button for button in app.button if button.label == "View selected results").click().run()
    assert any(title.value == "Evaluation Results" for title in app.title)

    app.radio[0].set_value("Dashboard").run()
    assert not app.exception
    assert any("80.0%" in item.value for item in app.markdown)

    database_path.unlink()
    assert not database_path.exists()


def test_public_demo_history_is_private_and_does_not_write_to_sqlite(monkeypatch, tmp_path):
    database_path = tmp_path / "must-not-be-created.sqlite"
    monkeypatch.setenv("DB_PATH", str(database_path))
    monkeypatch.delenv("HISTORY_STORAGE", raising=False)
    app_file = str(Path(__file__).resolve().parents[1] / "app.py")
    first = AppTest.from_file(app_file, default_timeout=15).run()
    first.session_state["active_dataset"] = pd.DataFrame([
        {"question": "Private question", "expected_answer": "Secret", "category": "Test"}
    ])
    first.session_state["active_dataset_name"] = "private.csv"
    first.radio[0].set_value("Model Comparison").run()
    next(button for button in first.button if button.label == "Run evaluation").click().run()
    assert not first.exception
    experiment_id = first.session_state["latest_experiment"]["experiment_id"]
    assert first.session_state["latest_experiment"]["dataset_name"] == "private.csv"

    second = AppTest.from_file(app_file, default_timeout=15).run()
    second.radio[0].set_value("Experiment History").run()
    assert not second.exception
    assert not second.dataframe
    assert not second.selectbox
    assert any("No saved evaluations" in item.value for item in second.info)

    second.radio[0].set_value("Model Comparison").run()
    assert "sample_dataset.csv" in second.text_input[0].value
    next(button for button in second.button if button.label == "Run evaluation").click().run()
    assert not second.exception
    second.radio[0].set_value("Experiment History").run()
    assert second.selectbox[0].options
    assert all("private.csv" not in option for option in second.selectbox[0].options)
    assert len(second.dataframe[-1].value) == 2

    first.radio[0].set_value("Experiment History").run()
    assert not first.exception
    assert first.selectbox[0].value == experiment_id
    next(button for button in first.button if button.label == "View selected results").click().run()
    assert first.session_state["latest_experiment"]["dataset_name"] == "private.csv"
    assert len(first.dataframe[-1].value) == 2
    first.radio[0].set_value("Dashboard").run()
    assert not first.exception
    assert any("100.0%" in item.value for item in first.markdown)
    assert not database_path.exists()
