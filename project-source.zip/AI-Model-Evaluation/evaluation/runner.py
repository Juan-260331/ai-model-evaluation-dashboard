from __future__ import annotations

import pandas as pd

from evaluation.dataset import REQUIRED_COLUMNS
from models.demo_models import DemoModel


def normalize_answer(answer: object) -> str:
    """Normalize capitalization and surrounding whitespace for exact-match scoring."""
    return str(answer).strip().casefold()


def exact_match(predicted: object, expected: object) -> bool:
    return normalize_answer(predicted) == normalize_answer(expected)


def compare_models(dataset: pd.DataFrame, models: tuple[DemoModel, DemoModel]) -> tuple[pd.DataFrame, dict[str, dict[str, object]]]:
    """Run both models against each row; return per-question records and actual metrics."""
    missing = [column for column in REQUIRED_COLUMNS if column not in dataset.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {', '.join(missing)}")
    if dataset.empty:
        raise ValueError("Cannot evaluate an empty dataset.")

    records: list[dict[str, object]] = []
    summary: dict[str, dict[str, object]] = {}
    for model in models:
        for index, row in enumerate(dataset.loc[:, list(REQUIRED_COLUMNS)].itertuples(index=False)):
            response = model.generate(str(row.question), str(row.expected_answer), index)
            passed = exact_match(response.answer, row.expected_answer)
            records.append({
                "question": str(row.question),
                "category": str(row.category),
                "expected_answer": str(row.expected_answer),
                "model_name": model.name,
                "predicted_answer": response.answer,
                "passed": passed,
                "status": "Pass" if passed else "Fail",
                "response_time_ms": response.response_time_ms,
            })

        model_rows = records[-len(dataset):]
        passed_count = sum(bool(record["passed"]) for record in model_rows)
        summary[model.name] = {
            "accuracy": passed_count / len(dataset),
            "passed": passed_count,
            "failed": len(dataset) - passed_count,
            "total": len(dataset),
            "average_response_time_ms": sum(float(r["response_time_ms"]) for r in model_rows) / len(model_rows),
        }

    return pd.DataFrame.from_records(records), summary
