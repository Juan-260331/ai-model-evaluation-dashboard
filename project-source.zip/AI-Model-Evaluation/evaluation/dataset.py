from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import BinaryIO

import pandas as pd

REQUIRED_COLUMNS = ("question", "expected_answer", "category")


def load_csv(source: str | Path | bytes | BinaryIO, filename: str | None = None) -> tuple[pd.DataFrame, dict[str, int]]:
    """Load and clean an evaluation CSV, reporting dropped and duplicate rows."""
    if filename is not None and Path(filename).suffix.lower() != ".csv":
        raise ValueError("Please upload a CSV file with a .csv extension.")
    if isinstance(source, (str, Path)) and Path(source).suffix.lower() != ".csv":
        raise ValueError("Please select a CSV file with a .csv extension.")
    try:
        # Answers such as "None", "NA", or "001" are text, not missing/numeric values.
        frame = pd.read_csv(
            BytesIO(source) if isinstance(source, bytes) else source,
            dtype=str,
            keep_default_na=False,
        )
    except (UnicodeDecodeError, pd.errors.ParserError, pd.errors.EmptyDataError) as exc:
        raise ValueError(f"Unable to read CSV: {exc}") from exc

    return validate_dataset(frame)


def validate_dataset(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, int]]:
    """Validate required columns, trim text, and remove incomplete/duplicate rows."""
    missing_columns = [column for column in REQUIRED_COLUMNS if column not in frame.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")

    cleaned = frame.loc[:, list(REQUIRED_COLUMNS)].copy()
    for column in REQUIRED_COLUMNS:
        cleaned[column] = cleaned[column].astype("string").str.strip()
        cleaned[column] = cleaned[column].replace("", pd.NA)

    before = len(cleaned)
    cleaned = cleaned.dropna(subset=list(REQUIRED_COLUMNS))
    dropped_empty = before - len(cleaned)
    duplicate_count = int(cleaned.duplicated(subset=list(REQUIRED_COLUMNS)).sum())
    cleaned = cleaned.drop_duplicates(subset=list(REQUIRED_COLUMNS), keep="first").reset_index(drop=True)
    if cleaned.empty:
        raise ValueError("No complete question rows remain after removing empty values.")
    cleaned = cleaned.astype({column: str for column in REQUIRED_COLUMNS})
    return cleaned, {"dropped_empty": dropped_empty, "duplicates_removed": duplicate_count}
