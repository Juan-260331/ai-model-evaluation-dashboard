from __future__ import annotations

import json
from typing import Any

import pandas as pd


def results_to_csv(results: pd.DataFrame) -> str:
    return results.to_csv(index=False)


def summary_to_json(summary: dict[str, Any], dataset_name: str, experiment_id: str | None = None) -> str:
    payload: dict[str, Any] = {
        "experiment_id": experiment_id,
        "dataset_name": dataset_name,
        "models": summary,
        "note": "Demo model metrics are generated locally; response times are simulated.",
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)
