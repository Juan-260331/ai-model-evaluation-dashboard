"""Dataset validation, evaluation, and report helpers."""
