"""Model adapters used by the evaluation dashboard."""
