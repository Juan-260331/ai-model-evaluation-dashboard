from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelResponse:
    answer: str
    response_time_ms: float


class DemoModel:
    """Deterministic, local-only stand-in; latency is simulated, not wall-clock."""

    def __init__(self, name: str, miss_period: int, miss_slots: frozenset[int], base_latency_ms: int, latency_span_ms: int):
        self.name = name
        self._miss_period = miss_period
        self._miss_slots = miss_slots
        self._base_latency_ms = base_latency_ms
        self._latency_span_ms = latency_span_ms

    def generate(self, question: str, expected_answer: str, index: int) -> ModelResponse:
        del question  # The demo adapter intentionally uses the supplied reference answer.
        slot = index % self._miss_period
        answer = f"Demo response: {expected_answer}" if slot in self._miss_slots else expected_answer
        latency = self._base_latency_ms + ((index * 7 + len(expected_answer)) % self._latency_span_ms)
        return ModelResponse(answer=answer, response_time_ms=float(latency))


class DemoModelA(DemoModel):
    def __init__(self) -> None:
        super().__init__("Demo Model A", 10, frozenset({4}), 38, 17)


class DemoModelB(DemoModel):
    def __init__(self) -> None:
        super().__init__("Demo Model B", 10, frozenset({2, 4, 7}), 76, 29)


def available_demo_models() -> tuple[DemoModel, DemoModel]:
    return DemoModelA(), DemoModelB()
