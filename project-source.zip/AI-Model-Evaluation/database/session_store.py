"""Session-scoped experiment history for public demos; never writes to disk."""

from __future__ import annotations

from collections.abc import MutableMapping
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


class SessionExperimentStore:
    def __init__(self, state: MutableMapping[str, Any]):
        self.state = state

    def save_experiment(
        self,
        dataset_name: str,
        summary: dict[str, dict[str, Any]],
        results: list[dict[str, Any]],
    ) -> dict[str, Any]:
        experiment = {
            "experiment_id": str(uuid4()),
            "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "dataset_name": dataset_name,
            "model_names": list(summary),
            "metrics": deepcopy(summary),
            "results": deepcopy(results),
        }
        self.state["experiments"] = [experiment, *self.state.get("experiments", [])]
        return deepcopy(experiment)

    def list_experiments(self) -> list[dict[str, Any]]:
        return [
            deepcopy({key: value for key, value in experiment.items() if key != "results"})
            for experiment in self.state.get("experiments", [])
        ]

    def get_experiment(self, experiment_id: str) -> dict[str, Any] | None:
        for experiment in self.state.get("experiments", []):
            if experiment["experiment_id"] == experiment_id:
                return deepcopy(experiment)
        return None
