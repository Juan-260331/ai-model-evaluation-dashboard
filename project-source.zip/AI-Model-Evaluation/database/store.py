from __future__ import annotations

import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

DEFAULT_DB_PATH = Path(__file__).resolve().with_name("experiments.db")


@contextmanager
def _connect(db_path: str | Path | None = None) -> Iterator[sqlite3.Connection]:
    path = Path(db_path or os.getenv("DB_PATH", DEFAULT_DB_PATH)).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    try:
        with connection:
            yield connection
    finally:
        connection.close()


def initialize_database(db_path: str | Path | None = None) -> None:
    with _connect(db_path) as connection:
        connection.execute(
            """CREATE TABLE IF NOT EXISTS experiments (
                experiment_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                dataset_name TEXT NOT NULL,
                model_names TEXT NOT NULL,
                metrics_json TEXT NOT NULL,
                results_json TEXT NOT NULL
            )"""
        )


def save_experiment(
    dataset_name: str,
    summary: dict[str, dict[str, Any]],
    results: list[dict[str, Any]],
    db_path: str | Path | None = None,
) -> dict[str, Any]:
    initialize_database(db_path)
    experiment = {
        "experiment_id": str(uuid.uuid4()),
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "dataset_name": dataset_name,
        "model_names": list(summary),
        "metrics": summary,
        "results": results,
    }
    with _connect(db_path) as connection:
        connection.execute(
            """INSERT INTO experiments
               (experiment_id, created_at, dataset_name, model_names, metrics_json, results_json)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                experiment["experiment_id"], experiment["created_at"], dataset_name,
                json.dumps(experiment["model_names"]), json.dumps(summary),
                json.dumps(results, ensure_ascii=False),
            ),
        )
    return experiment


def list_experiments(db_path: str | Path | None = None) -> list[dict[str, Any]]:
    initialize_database(db_path)
    with _connect(db_path) as connection:
        rows = connection.execute(
            """SELECT experiment_id, created_at, dataset_name, model_names, metrics_json
               FROM experiments ORDER BY created_at DESC, rowid DESC"""
        ).fetchall()
    return [
        {
            "experiment_id": row["experiment_id"],
            "created_at": row["created_at"],
            "dataset_name": row["dataset_name"],
            "model_names": json.loads(row["model_names"]),
            "metrics": json.loads(row["metrics_json"]),
        }
        for row in rows
    ]


def get_experiment(experiment_id: str, db_path: str | Path | None = None) -> dict[str, Any] | None:
    initialize_database(db_path)
    with _connect(db_path) as connection:
        row = connection.execute(
            "SELECT * FROM experiments WHERE experiment_id = ?", (experiment_id,)
        ).fetchone()
    if row is None:
        return None
    return {
        "experiment_id": row["experiment_id"],
        "created_at": row["created_at"],
        "dataset_name": row["dataset_name"],
        "model_names": json.loads(row["model_names"]),
        "metrics": json.loads(row["metrics_json"]),
        "results": json.loads(row["results_json"]),
    }
