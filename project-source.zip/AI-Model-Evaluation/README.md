# AI Model Evaluation Dashboard

A Streamlit portfolio application ready for Community Cloud. Upload a CSV, run a repeatable evaluation, review per-question and category results, download reports, and revisit experiments in your current browser session. History is isolated between visitor sessions by default. SQLite persistence remains available as an explicit option for single-user local use.

> **Demo-only evaluation:** Demo Model A and Demo Model B are deterministic local simulations, **not real LLMs**. They produce answers using the supplied expected answer and fixed rules that intentionally yield different pass rates. Their response times are simulated values, not measurements of actual inference. Accuracy and pass/fail metrics are calculated from each run; dashboard aggregates come from the experiments saved locally. This project does not call an AI provider or require an API key.

## Features

- **Dashboard:** evaluation counts, distinct models, saved-run average accuracy and response time, and recent experiments.
- **Datasets:** built-in 60-question benchmark and CSV upload with required-column validation, incomplete-row removal, duplicate detection/removal, cleanup counts, and a preview.
- **Model comparison:** evaluates both deterministic demo models on the same selected dataset.
- **Evaluation results:** case-insensitive, surrounding-whitespace-trimmed exact match; per-question pass/fail; simulated response times; overall and per-category Plotly charts.
- **Exports:** per-question CSV and experiment-summary JSON.
- **Experiment history:** session-scoped run metadata, metrics, and question-level results; saved results can be opened again while the session is active. Optional local SQLite persistence.

The included benchmark has 20 answered questions in each category: Mathematics, General Knowledge, and Programming.

## Technology

- Python 3.12 recommended for deployment
- Streamlit for the web interface
- pandas for dataset and result processing
- Plotly for interactive charts
- Streamlit session state for public demos; SQLite for optional local history
- python-dotenv for optional environment settings
- pytest and Streamlit AppTest for automated tests

## Windows installation and startup

In PowerShell, from the project directory:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
streamlit run app.py
```

Open the address printed by Streamlit, usually `http://localhost:8501`.

If PowerShell prevents environment activation, allow activation for the current terminal only and activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

By default, uploaded data and history are kept in the current Streamlit session, not in a shared database. Refreshing the page or starting a new session resets that history. Download CSV/JSON reports before leaving. There are no accounts or durable cloud storage.

For a **single-user local installation only**, set `HISTORY_STORAGE=sqlite` in `.env`. The application then creates `database/experiments.db` as needed. To choose another file, set `DB_PATH`. Actual `.env` files, secrets, and SQLite data files are excluded from Git. Do not enable SQLite mode on a public deployment: it has no user isolation.

## Deploy to Streamlit Community Cloud

See [部署说明.md](部署说明.md) for the Chinese checklist.

1. Upload this project's contents to a GitHub repository. Keep `app.py`, `requirements.txt`, `.streamlit/`, `data/`, `database/`, `evaluation/`, and `models/`. Exclude virtual environments, actual `.env` files, secrets, caches, and SQLite database files.
2. Sign in at [Streamlit Community Cloud](https://share.streamlit.io/), select **Create app → Yup, I have an app**, and select the repository, branch, and entrypoint **`app.py`**.
3. Under **Advanced settings**, select **Python 3.12**. No API keys or secrets are needed. Leave `HISTORY_STORAGE` unset (or `session`); do not set it to `sqlite`.
4. Deploy. Once ready, open the generated `*.streamlit.app` URL in a separate private browser session and run the built-in sample. Check the dashboard after evaluation and download both reports.
5. To allow people with the link to visit, verify the app's sharing settings are public. Share the generated URL after that check.

The repository's `.streamlit/config.toml` supplies the light theme and a 10 MB upload limit. The root `requirements.txt` contains pinned runtime dependencies; test dependencies are separate. A GitHub Actions workflow runs tests with Python 3.12 on pushes and pull requests.

Official references: [deployment](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy), [file organization](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/file-organization), and [session-state lifecycle](https://docs.streamlit.io/develop/api-reference/caching-and-state/st.session_state).

## Run automated tests

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
python -m pytest -q
```

The complete test suite covers CSV validation and cleanup, answer normalization, scoring, model comparison and repeatability, report content, SQLite save/read, the built-in benchmark, and a Streamlit AppTest workflow. The AppTest workflow covers all five navigation pages, invalid and valid CSV uploads, an evaluation using the uploaded dataset, rendered CSV/JSON downloads, and saved-history retrieval.

The tests also cover returning to a populated dashboard and isolation between independent public-demo sessions. See `验收记录.md` for the current validation result.

Streamlit AppTest simulates the app and widget interactions in-process, not a real browser session or a network download. It verifies both download controls render, report serialization/content, and advertised `.csv` / `.json` file types. A separate local browser check also downloaded both reports successfully; see `验收记录.md`. Cloud behavior must be checked again after deployment.

## CSV format

Supply a `.csv` file with these required headers:

```csv
question,expected_answer,category
What is 2 + 2?,4,Mathematics
```

Rows missing any required value are removed. Exact duplicate question/answer/category rows are deduplicated. A dataset with no complete rows is rejected.

## Project layout

```text
app.py                  Streamlit application
evaluation/             CSV validation, exact-match scoring, report serialization
models/                 Deterministic demo model adapters
database/               SQLite persistence
database/session_store.py Session-isolated public-demo history
data/sample_dataset.csv Built-in 60-question dataset
tests/                  pytest and Streamlit AppTest coverage
requirements.txt        Pinned runtime dependencies
requirements-dev.txt    Test dependencies
.streamlit/config.toml  Theme and upload settings
.github/workflows/      Python 3.12 CI
.env.example            Optional local environment settings
.gitignore              Excludes virtual environment and local data
```

## Known limitations

- The models are reference-answer-driven simulations; they do not measure real-world model quality. Their accuracy should not be presented as a real LLM benchmark.
- Response times are deterministic simulated values, not wall-clock or inference latency.
- Exact match checks only trimmed, case-insensitive string equality. Semantic similarity, LLM-as-a-judge, and reference-free evaluation are not implemented.
- Public-demo history lives only in each browser session and is reset on refresh/new sessions or server restart. Optional SQLite mode is for single-user local use only. There are no user accounts or durable cloud storage.
- CSV/JSON report content and controls are covered by AppTest. Actual downloads were checked separately in a local browser; the public cloud URL still requires post-deployment validation.

## Extension point

`models/demo_models.py` documents the current model adapter interface. A future real provider adapter could implement that interface without changing the existing evaluator, but no provider integration is included in this demo.
