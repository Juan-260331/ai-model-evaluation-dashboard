from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

from database import store as sqlite_store
from database.session_store import SessionExperimentStore
from evaluation.dataset import load_csv
from evaluation.exporters import results_to_csv, summary_to_json
from evaluation.runner import compare_models
from models.demo_models import available_demo_models

ROOT = Path(__file__).resolve().parent
SAMPLE_DATASET = ROOT / "data" / "sample_dataset.csv"
NAVIGATION = ("Dashboard", "Datasets", "Model Comparison", "Evaluation Results", "Experiment History")

load_dotenv(ROOT / ".env")
st.set_page_config(page_title="AI Model Evaluation", page_icon="◈", layout="wide", initial_sidebar_state="expanded")

st.markdown(
    """
    <style>
    .stApp { background: #f5f7fb; color: #172033; }
    [data-testid="stSidebar"] { background: #111827; }
    [data-testid="stSidebar"] * { color: #e6eaf2; }
    [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p { color: #aab4c5; }
    .block-container { max-width: 1440px; padding-top: 2rem; }
    .eyebrow { color: #68758a; text-transform: uppercase; letter-spacing: .12em; font-size: .75rem; font-weight: 700; }
    .metric-card { background: white; border: 1px solid #e6eaf0; border-radius: 12px; padding: 18px 20px; min-height: 108px; }
    .metric-label { color: #68758a; font-size: .85rem; margin-bottom: 8px; }
    .metric-value { color: #172033; font-weight: 700; font-size: 1.65rem; }
    .demo-note { background: #fff7e6; border: 1px solid #ffe3a3; color: #805c0a; padding: 12px 16px; border-radius: 10px; }
    div[data-testid="stDataFrame"] { border: 1px solid #e6eaf0; border-radius: 10px; }
    </style>
    """,
    unsafe_allow_html=True,
)


def metric_card(label: str, value: str) -> None:
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value">{value}</div></div>',
        unsafe_allow_html=True,
    )


def page_title(title: str, subtitle: str) -> None:
    st.markdown('<div class="eyebrow">AI Model Evaluation Platform</div>', unsafe_allow_html=True)
    st.title(title)
    st.caption(subtitle)


def experiment_store():
    # Shared SQLite history is an explicit option for a single-user local install.
    if os.getenv("HISTORY_STORAGE", "session").strip().lower() == "sqlite":
        return sqlite_store
    return SessionExperimentStore(st.session_state)


def current_dataset() -> tuple[pd.DataFrame, str]:
    if "active_dataset" in st.session_state:
        return st.session_state["active_dataset"].copy(), st.session_state["active_dataset_name"]
    frame, _ = load_csv(SAMPLE_DATASET, SAMPLE_DATASET.name)
    return frame, SAMPLE_DATASET.name


def render_dashboard() -> None:
    page_title("Evaluation Dashboard", "Monitor your experiment activity and compare model performance.")
    experiments = experiment_store().list_experiments()
    all_models = {
        model_name
        for experiment in experiments
        for model_name in experiment["model_names"]
    }
    metric_records = [
        {"Model": name, "Accuracy": values["accuracy"] * 100, "Avg. response time (ms)": values["average_response_time_ms"]}
        for experiment in experiments
        for name, values in experiment["metrics"].items()
    ]
    accuracies = [record["Accuracy"] for record in metric_records]
    response_times = [record["Avg. response time (ms)"] for record in metric_records]
    columns = st.columns(4)
    values = (
        (str(len(experiments)), "Total Evaluations"),
        (str(len(all_models)), "Models Compared"),
        (f"{sum(accuracies) / len(accuracies):.1f}%" if accuracies else "—", "Average Accuracy"),
        (f"{sum(response_times) / len(response_times):.1f} ms" if response_times else "—", "Average Response Time"),
    )
    for column, (value, label) in zip(columns, values):
        with column:
            metric_card(label, value)
    st.write("")

    left, right = st.columns([1.25, 1])
    with left:
        st.subheader("Model accuracy")
        if metric_records:
            model_frame = pd.DataFrame(metric_records)
            chart_data = model_frame.groupby("Model", as_index=False)["Accuracy"].mean()
            figure = px.bar(chart_data, x="Model", y="Accuracy", color="Model", text_auto=".1f",
                            color_discrete_sequence=["#5b67e8", "#18a999"], range_y=[0, 100])
            figure.update_layout(showlegend=False, yaxis_title="Accuracy (%)", xaxis_title=None, plot_bgcolor="white")
            st.plotly_chart(figure, width="stretch")
        else:
            st.info("Run your first evaluation to see model accuracy here.")
    with right:
        st.subheader("Recent evaluations")
        if experiments:
            recent = []
            for experiment in experiments[:5]:
                scores = " · ".join(f"{name}: {metrics['accuracy']:.0%}" for name, metrics in experiment["metrics"].items())
                recent.append({
                    "Date": experiment["created_at"].replace("T", " ")[:19],
                    "Dataset": experiment["dataset_name"],
                    "Accuracy": scores,
                })
            st.dataframe(pd.DataFrame(recent), hide_index=True, width="stretch")
        else:
            st.info("No experiment records yet. Start an evaluation to populate your history.")
    st.markdown('<div class="demo-note">Demo Model A and Demo Model B are deterministic local simulations. No external AI service is called; response times are simulated.</div>', unsafe_allow_html=True)


def render_datasets() -> None:
    page_title("Datasets", "Upload and validate question sets or start with the included 60-row benchmark.")
    sample, _ = load_csv(SAMPLE_DATASET, SAMPLE_DATASET.name)
    st.subheader("Built-in sample dataset")
    st.write(f"{len(sample)} questions across Mathematics, General Knowledge, and Programming.")
    st.dataframe(sample.head(10), hide_index=True, width="stretch")
    if st.button("Use built-in sample dataset", type="secondary"):
        st.session_state["active_dataset"] = sample
        st.session_state["active_dataset_name"] = SAMPLE_DATASET.name
        st.success(f"Selected {SAMPLE_DATASET.name}.")

    st.divider()
    st.subheader("Upload a CSV dataset")
    st.caption("Required columns: question, expected_answer, category. Blank rows are removed and exact duplicates are deduplicated.")
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"], key="dataset_upload")
    if uploaded is not None:
        try:
            frame, report = load_csv(uploaded.getvalue(), uploaded.name)
            st.success(f"Validated {len(frame)} usable rows.")
            if report["dropped_empty"] or report["duplicates_removed"]:
                st.info(f"Removed {report['dropped_empty']} incomplete row(s) and {report['duplicates_removed']} duplicate row(s).")
            st.dataframe(frame.head(20), hide_index=True, width="stretch")
            if st.button("Use uploaded dataset", type="primary"):
                st.session_state["active_dataset"] = frame
                st.session_state["active_dataset_name"] = uploaded.name
                st.success(f"Selected {uploaded.name} for the next evaluation.")
        except ValueError as exc:
            st.error(str(exc))


def render_comparison() -> None:
    page_title("Model Comparison", "Run both local demo models against exactly the same dataset.")
    st.markdown('<div class="demo-note"><strong>Simulation:</strong> Both models are deterministic stand-ins, not live LLMs. Accuracy is scored from generated answers; latency values are simulated.</div>', unsafe_allow_html=True)
    dataset, dataset_name = current_dataset()
    st.subheader("Evaluation setup")
    col1, col2 = st.columns(2)
    with col1:
        st.text_input("Dataset", value=f"{dataset_name} · {len(dataset)} questions", disabled=True)
    with col2:
        st.text_input("Models", value="Demo Model A  vs  Demo Model B", disabled=True)
    with st.expander("Preview evaluation data"):
        st.dataframe(dataset.head(10), hide_index=True, width="stretch")
    if st.button("Run evaluation", type="primary", width="stretch"):
        with st.spinner("Running deterministic demo evaluation..."):
            results, summary = compare_models(dataset, available_demo_models())
            experiment = experiment_store().save_experiment(dataset_name, summary, results.to_dict(orient="records"))
            st.session_state["latest_experiment"] = experiment
            st.session_state["pending_navigation"] = "Evaluation Results"
        st.success(f"Evaluation completed and saved. Experiment ID: {experiment['experiment_id']}")
        st.rerun()


def render_results(experiment: dict | None) -> None:
    page_title("Evaluation Results", "Inspect per-model metrics, category accuracy, and per-question outcomes.")
    if not experiment:
        st.info("No results to display yet. Run an evaluation or open a saved experiment from history.")
        return
    summary = experiment["metrics"]
    results = pd.DataFrame(experiment["results"])
    st.caption(f"Experiment {experiment['experiment_id']} · {experiment['dataset_name']} · {experiment['created_at']}")
    st.markdown('<div class="demo-note">These are measured outputs of the deterministic demo models. Response times are simulated model latencies.</div>', unsafe_allow_html=True)

    metrics_cols = st.columns(2)
    for column, (model_name, metrics) in zip(metrics_cols, summary.items()):
        with column:
            st.subheader(model_name)
            a, b, c = st.columns(3)
            with a:
                metric_card("Exact match accuracy", f"{metrics['accuracy']:.1%}")
            with b:
                metric_card("Average response time", f"{metrics['average_response_time_ms']:.1f} ms")
            with c:
                metric_card("Pass / Fail", f"{metrics['passed']} / {metrics['failed']}")

    chart_col, category_col = st.columns(2)
    with chart_col:
        st.subheader("Accuracy comparison")
        accuracy_frame = pd.DataFrame([{"Model": name, "Accuracy": metrics["accuracy"] * 100} for name, metrics in summary.items()])
        fig = px.bar(accuracy_frame, x="Model", y="Accuracy", color="Model", text_auto=".1f",
                     color_discrete_sequence=["#5b67e8", "#18a999"], range_y=[0, 100])
        fig.update_layout(showlegend=False, yaxis_title="Accuracy (%)", xaxis_title=None, plot_bgcolor="white")
        st.plotly_chart(fig, width="stretch")
    with category_col:
        st.subheader("Accuracy by category")
        category_frame = results.groupby(["category", "model_name"], as_index=False)["passed"].mean()
        category_frame["Accuracy (%)"] = category_frame["passed"] * 100
        fig = px.bar(category_frame, x="category", y="Accuracy (%)", color="model_name", barmode="group",
                     color_discrete_sequence=["#5b67e8", "#18a999"], range_y=[0, 100])
        fig.update_layout(xaxis_title=None, plot_bgcolor="white", legend_title="Model")
        st.plotly_chart(fig, width="stretch")

    st.subheader("Per-question results")
    st.dataframe(results, hide_index=True, width="stretch")
    csv_report = results_to_csv(results)
    json_report = summary_to_json(summary, experiment["dataset_name"], experiment["experiment_id"])
    col1, col2 = st.columns(2)
    with col1:
        st.download_button("Download per-question results (CSV)", data=csv_report, file_name="evaluation_results.csv",
                           mime="text/csv", width="stretch")
    with col2:
        st.download_button("Download experiment summary (JSON)", data=json_report, file_name="experiment_summary.json",
                           mime="application/json", width="stretch")


def render_history() -> None:
    persistent = os.getenv("HISTORY_STORAGE", "session").strip().lower() == "sqlite"
    subtitle = (
        "Review past runs persisted in your local SQLite database."
        if persistent else
        "History is private to this browser session. Download reports before refreshing or leaving."
    )
    page_title("Experiment History", subtitle)
    experiments = experiment_store().list_experiments()
    if not experiments:
        st.info("No saved evaluations yet. Run a model comparison to create your first record.")
        return
    table_rows = []
    for experiment in experiments:
        for model_name, metrics in experiment["metrics"].items():
            table_rows.append({
                "Experiment ID": experiment["experiment_id"],
                "Created At": experiment["created_at"].replace("T", " ")[:19],
                "Dataset": experiment["dataset_name"],
                "Model": model_name,
                "Accuracy": f"{metrics['accuracy']:.1%}",
                "Avg. Response Time": f"{metrics['average_response_time_ms']:.1f} ms",
            })
    st.dataframe(pd.DataFrame(table_rows), hide_index=True, width="stretch")
    selected_id = st.selectbox("Open experiment", options=[item["experiment_id"] for item in experiments],
                               format_func=lambda value: f"{value[:8]} · {next(e['dataset_name'] for e in experiments if e['experiment_id'] == value)} · {value}")
    selected = experiment_store().get_experiment(selected_id)
    if selected and st.button("View selected results", type="primary"):
        st.session_state["latest_experiment"] = selected
        st.session_state["pending_navigation"] = "Evaluation Results"
        st.rerun()


def main() -> None:
    pending_page = st.session_state.pop("pending_navigation", None)
    if pending_page:
        st.session_state["navigation"] = pending_page
    with st.sidebar:
        st.markdown("## ◈ ModelBench")
        st.markdown("AI evaluation workspace")
        page = st.radio("Navigation", NAVIGATION, key="navigation", label_visibility="collapsed")
        st.divider()
        st.caption("DEMO MODE")
        st.caption("No API keys · No external calls")
        if os.getenv("HISTORY_STORAGE", "session").strip().lower() != "sqlite":
            st.caption("History is private to this session and resets on refresh. Download reports to keep them.")

    if page == "Dashboard":
        render_dashboard()
    elif page == "Datasets":
        render_datasets()
    elif page == "Model Comparison":
        render_comparison()
    elif page == "Evaluation Results":
        render_results(st.session_state.get("latest_experiment"))
    else:
        render_history()


if __name__ == "__main__":
    main()
